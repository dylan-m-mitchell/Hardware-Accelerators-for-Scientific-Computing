`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/25/2025 03:12:56 PM
// Design Name: 
// Module Name: FFT4_TB
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module FFT4_TB();
  localparam T = 10;
  
  wire [63:0]M_AXIS_RESULT_B1_Xi_0_tdata;
  wire M_AXIS_RESULT_B1_Xi_0_tvalid;
  wire [63:0]M_AXIS_RESULT_B1_Xr_0_tdata;
  wire M_AXIS_RESULT_B1_Xr_0_tvalid;
  wire [63:0]M_AXIS_RESULT_B1_Yi_0_tdata;
  wire M_AXIS_RESULT_B1_Yi_0_tvalid;
  wire [63:0]M_AXIS_RESULT_B1_Yr_0_tdata;
  wire M_AXIS_RESULT_B1_Yr_0_tvalid;
  wire [63:0]M_AXIS_RESULT_B2_Xi_0_tdata;
  wire M_AXIS_RESULT_B2_Xi_0_tvalid;
  wire [63:0]M_AXIS_RESULT_B2_Xr_0_tdata;
  wire M_AXIS_RESULT_B2_Xr_0_tvalid;
  wire [63:0]M_AXIS_RESULT_B2_Yi_0_tdata;
  wire M_AXIS_RESULT_B2_Yi_0_tvalid;
  wire [63:0]M_AXIS_RESULT_B2_Yr_0_tdata;
  wire M_AXIS_RESULT_B2_Yr_0_tvalid;
  wire S_AXIS_B1_Ai_0_tready;
  wire S_AXIS_B1_Ar_0_tready;
  wire S_AXIS_B1_Bi_0_tready;
  wire S_AXIS_B1_Br_0_tready;
  wire S_AXIS_F1_B1_Wi_tready;
  wire S_AXIS_F1_B1_Wr_tready;
  wire S_AXIS_B2_Ai_0_tready;
  wire S_AXIS_B2_Ar_0_tready;
  wire S_AXIS_B2_Bi_0_tready;
  wire S_AXIS_B2_Br_0_tready;
  wire S_AXIS_F1_B2_Wi_tready;
  wire S_AXIS_F1_B2_Wr_tready;
  wire S_AXIS_F2_B1_Wi_tready;
  wire S_AXIS_F2_B1_Wr_tready;
  wire S_AXIS_F2_B2_Wi_tready;
  wire S_AXIS_F2_B2_Wr_tready;
  
  reg aclk;
  reg aresetn;
  reg B1_Ai_0_tready;
  reg B1_Ar_0_tready;
  reg B1_Bi_0_tready;
  reg B1_Br_0_tready;
  reg B1_Wi_0_tready;
  reg B1_Wi_1_tready;
  reg B1_Wr_0_tready;
  reg B1_Wr_1_tready;
  reg B2_Ai_0_tready;
  reg B2_Ar_0_tready;
  reg B2_Bi_0_tready;
  reg B2_Br_0_tready;
  reg B2_Wi_0_tready;
  reg B2_Wi_1_tready;
  reg B2_Wr_0_tready;
  reg B2_Wr_1_tready;
  reg M_AXIS_RESULT_B1_Xi_0_tready;
  reg M_AXIS_RESULT_B1_Xr_0_tready;
  reg M_AXIS_RESULT_B1_Yi_0_tready;
  reg M_AXIS_RESULT_B1_Yr_0_tready;
  reg M_AXIS_RESULT_B2_Xi_0_tready;
  reg M_AXIS_RESULT_B2_Xr_0_tready;
  reg M_AXIS_RESULT_B2_Yi_0_tready;
  reg M_AXIS_RESULT_B2_Yr_0_tready;
  reg [63:0]S_AXIS_B1_Ai_0_tdata;
  reg [63:0]S_AXIS_B1_Ar_0_tdata;
  reg [63:0]S_AXIS_B1_Bi_0_tdata;
  reg [63:0]S_AXIS_B1_Br_0_tdata;
  reg [63:0]S_AXIS_F1_B1_Wi_tdata;
  reg [63:0]S_AXIS_F1_B1_Wr_tdata;
  reg [63:0]S_AXIS_B2_Ai_0_tdata;
  reg [63:0]S_AXIS_B2_Ar_0_tdata;
  reg [63:0]S_AXIS_B2_Bi_0_tdata;
  reg [63:0]S_AXIS_B2_Br_0_tdata;
  reg [63:0]S_AXIS_F1_B2_Wi_tdata;
  reg [63:0]S_AXIS_F1_B2_Wr_tdata;
  reg [63:0]S_AXIS_F2_B1_Wi_tdata;
  reg [63:0]S_AXIS_F2_B1_Wr_tdata;
  reg [63:0]S_AXIS_F2_B2_Wi_tdata;
  reg [63:0]S_AXIS_F2_B2_Wr_tdata;
  reg S_AXIS_B1_Ai_0_tvalid;
  reg S_AXIS_B1_Ar_0_tvalid;
  reg S_AXIS_B1_Bi_0_tvalid;
  reg S_AXIS_B1_Br_0_tvalid;
  reg S_AXIS_F1_B1_Wi_tvalid;
  reg S_AXIS_F1_B1_Wr_tvalid;
  reg S_AXIS_B2_Ai_0_tvalid;
  reg S_AXIS_B2_Ar_0_tvalid;
  reg S_AXIS_B2_Bi_0_tvalid;
  reg S_AXIS_B2_Br_0_tvalid;
  reg S_AXIS_F1_B2_Wi_tvalid;
  reg S_AXIS_F1_B2_Wr_tvalid;
  reg S_AXIS_F2_B1_Wi_tvalid;
  reg S_AXIS_F2_B1_Wr_tvalid;
  reg S_AXIS_F2_B2_Wi_tvalid;
  reg S_AXIS_F2_B2_Wr_tvalid;
  
  always
  begin
    aclk = 0;
    #(T/2);
    aclk = 1;
    #(T/2);
  end
  
  assign S_AXIS_B1_Ai_0_tready = B1_Ai_0_tready;
  assign S_AXIS_B1_Ar_0_tready = B1_Ar_0_tready;
  assign S_AXIS_B1_Bi_0_tready = B1_Bi_0_tready;
  assign S_AXIS_B1_Br_0_tready = B1_Br_0_tready;
  assign S_AXIS_F1_B1_Wi_tready = B1_Wi_0_tready;
  assign S_AXIS_F1_B1_Wr_tready = B1_Wi_1_tready;
  assign S_AXIS_B2_Ai_0_tready = B1_Wr_0_tready;
  assign S_AXIS_B2_Ar_0_tready = B1_Wr_1_tready;
  assign S_AXIS_B2_Bi_0_tready = B2_Ai_0_tready;
  assign S_AXIS_B2_Br_0_tready = B2_Ar_0_tready;
  assign S_AXIS_F1_B2_Wi_tready = B2_Bi_0_tready;
  assign S_AXIS_F1_B2_Wr_tready = B2_Br_0_tready;
  assign S_AXIS_F2_B1_Wi_tready = B2_Wi_0_tready;
  assign S_AXIS_F2_B1_Wr_tready = B2_Wi_1_tready;
  assign S_AXIS_F2_B2_Wi_tready = B2_Wr_0_tready;
  assign S_AXIS_F2_B2_Wr_tready = B2_Wr_1_tready;

  initial
  begin
    M_AXIS_RESULT_B1_Xi_0_tready = 1;
    M_AXIS_RESULT_B1_Xr_0_tready = 1;
    M_AXIS_RESULT_B1_Yi_0_tready = 1;
    M_AXIS_RESULT_B1_Yr_0_tready = 1;
    M_AXIS_RESULT_B2_Xi_0_tready = 1;
    M_AXIS_RESULT_B2_Xr_0_tready = 1;
    M_AXIS_RESULT_B2_Yi_0_tready = 1;
    M_AXIS_RESULT_B2_Yr_0_tready = 1;
    S_AXIS_B1_Ai_0_tvalid = 0;
    S_AXIS_B1_Ar_0_tvalid = 0;
    S_AXIS_B1_Bi_0_tvalid = 0;
    S_AXIS_B1_Br_0_tvalid = 0;
    S_AXIS_F1_B1_Wi_tvalid = 0;
    S_AXIS_F1_B1_Wr_tvalid = 0;
    S_AXIS_B2_Ai_0_tvalid = 0;
    S_AXIS_B2_Ar_0_tvalid = 0;
    S_AXIS_B2_Bi_0_tvalid = 0;
    S_AXIS_B2_Br_0_tvalid = 0;
    S_AXIS_F1_B2_Wi_tvalid = 0;
    S_AXIS_F1_B2_Wr_tvalid = 0;
    S_AXIS_F2_B1_Wi_tvalid = 0;
    S_AXIS_F2_B1_Wr_tvalid = 0;
    S_AXIS_F2_B2_Wi_tvalid = 0;
    S_AXIS_F2_B2_Wr_tvalid = 0;             
    S_AXIS_B1_Ai_0_tdata = 0;
    S_AXIS_B1_Ar_0_tdata = 0;
    S_AXIS_B1_Bi_0_tdata = 0;
    S_AXIS_B1_Br_0_tdata = 0;
    S_AXIS_F1_B1_Wi_tdata = 0;
    S_AXIS_F1_B1_Wr_tdata = 0;
    S_AXIS_B2_Ai_0_tdata = 0;
    S_AXIS_B2_Ar_0_tdata = 0;
    S_AXIS_B2_Bi_0_tdata = 0;
    S_AXIS_B2_Br_0_tdata = 0;
    S_AXIS_F1_B2_Wi_tdata = 0;
    S_AXIS_F1_B2_Wr_tdata = 0;
    S_AXIS_F2_B1_Wi_tdata = 0;
    S_AXIS_F2_B1_Wr_tdata = 0;
    S_AXIS_F2_B2_Wi_tdata = 0;
    S_AXIS_F2_B2_Wr_tdata = 0;
    B1_Ai_0_tready = 1;
    B1_Ar_0_tready = 1;
    B1_Bi_0_tready = 1;
    B1_Br_0_tready = 1;
    B1_Wi_0_tready = 1;
    B1_Wi_1_tready = 1;
    B1_Wr_0_tready = 1;
    B1_Wr_1_tready = 1;
    B2_Ai_0_tready = 1;
    B2_Ar_0_tready = 1;
    B2_Bi_0_tready = 1;
    B2_Br_0_tready = 1;
    B2_Wi_0_tready = 1;
    B2_Wi_1_tready = 1;
    B2_Wr_0_tready = 1;
    B2_Wr_1_tready = 1;
  
  // Reset
	aresetn = 0;
    #(T*5);
    aresetn = 1;
    #(T*5);
    
  // Make data available
    S_AXIS_B1_Ar_0_tdata = 64'h3FF0000000000000; // 1
    S_AXIS_B1_Ai_0_tdata = 64'h0000000000000000; // 0
    S_AXIS_B1_Br_0_tdata = 64'h4008000000000000; // 3
    S_AXIS_B1_Bi_0_tdata = 64'h0000000000000000; // 0
    
    S_AXIS_B2_Ar_0_tdata = 64'h4000000000000000; // 2
    S_AXIS_B2_Ai_0_tdata = 64'h0000000000000000; // 0
    S_AXIS_B2_Br_0_tdata = 64'h4010000000000000; // 4
    S_AXIS_B2_Bi_0_tdata = 64'h0000000000000000; // 0
    
  // Twiddle factors
    S_AXIS_F1_B1_Wr_tdata = 64'h3FF0000000000000; // 1
    S_AXIS_F1_B1_Wi_tdata = 64'h0000000000000000; // 0
    S_AXIS_F1_B2_Wr_tdata = 64'h3FF0000000000000; // 1
    S_AXIS_F1_B2_Wi_tdata = 64'h0000000000000000; // 0
    
    S_AXIS_F2_B1_Wr_tdata = 64'h3FF0000000000000; // 1 
    S_AXIS_F2_B1_Wi_tdata = 64'h0000000000000000; // 0 
    S_AXIS_F2_B2_Wr_tdata = 64'h0000000000000000; // 0 
    S_AXIS_F2_B2_Wi_tdata = 64'hBFF0000000000000; // -1
      
  // Tvalids
    S_AXIS_B1_Ai_0_tvalid = 1;
    S_AXIS_B1_Ar_0_tvalid = 1;
    S_AXIS_B1_Bi_0_tvalid = 1;
    S_AXIS_B1_Br_0_tvalid = 1;
    S_AXIS_F1_B1_Wi_tvalid = 1;
    S_AXIS_F1_B1_Wr_tvalid = 1;
    S_AXIS_B2_Ai_0_tvalid = 1;
    S_AXIS_B2_Ar_0_tvalid = 1;
    S_AXIS_B2_Bi_0_tvalid = 1;
    S_AXIS_B2_Br_0_tvalid = 1;
    S_AXIS_F1_B2_Wi_tvalid = 1;
    S_AXIS_F1_B2_Wr_tvalid = 1;
    S_AXIS_F2_B1_Wi_tvalid = 1;
    S_AXIS_F2_B1_Wr_tvalid = 1;
    S_AXIS_F2_B2_Wi_tvalid = 1;
    S_AXIS_F2_B2_Wr_tvalid = 1;
  
  #(T*20);
end

  FFT_4 dut
       (.M_AXIS_RESULT_B1_Xi_0_tdata(M_AXIS_RESULT_B1_Xi_0_tdata),
        .M_AXIS_RESULT_B1_Xi_0_tready(M_AXIS_RESULT_B1_Xi_0_tready),
        .M_AXIS_RESULT_B1_Xi_0_tvalid(M_AXIS_RESULT_B1_Xi_0_tvalid),
        .M_AXIS_RESULT_B1_Xr_0_tdata(M_AXIS_RESULT_B1_Xr_0_tdata),
        .M_AXIS_RESULT_B1_Xr_0_tready(M_AXIS_RESULT_B1_Xr_0_tready),
        .M_AXIS_RESULT_B1_Xr_0_tvalid(M_AXIS_RESULT_B1_Xr_0_tvalid),
        .M_AXIS_RESULT_B1_Yi_0_tdata(M_AXIS_RESULT_B1_Yi_0_tdata),
        .M_AXIS_RESULT_B1_Yi_0_tready(M_AXIS_RESULT_B1_Yi_0_tready),
        .M_AXIS_RESULT_B1_Yi_0_tvalid(M_AXIS_RESULT_B1_Yi_0_tvalid),
        .M_AXIS_RESULT_B1_Yr_0_tdata(M_AXIS_RESULT_B1_Yr_0_tdata),
        .M_AXIS_RESULT_B1_Yr_0_tready(M_AXIS_RESULT_B1_Yr_0_tready),
        .M_AXIS_RESULT_B1_Yr_0_tvalid(M_AXIS_RESULT_B1_Yr_0_tvalid),
        .M_AXIS_RESULT_B2_Xi_0_tdata(M_AXIS_RESULT_B2_Xi_0_tdata),
        .M_AXIS_RESULT_B2_Xi_0_tready(M_AXIS_RESULT_B2_Xi_0_tready),
        .M_AXIS_RESULT_B2_Xi_0_tvalid(M_AXIS_RESULT_B2_Xi_0_tvalid),
        .M_AXIS_RESULT_B2_Xr_0_tdata(M_AXIS_RESULT_B2_Xr_0_tdata),
        .M_AXIS_RESULT_B2_Xr_0_tready(M_AXIS_RESULT_B2_Xr_0_tready),
        .M_AXIS_RESULT_B2_Xr_0_tvalid(M_AXIS_RESULT_B2_Xr_0_tvalid),
        .M_AXIS_RESULT_B2_Yi_0_tdata(M_AXIS_RESULT_B2_Yi_0_tdata),
        .M_AXIS_RESULT_B2_Yi_0_tready(M_AXIS_RESULT_B2_Yi_0_tready),
        .M_AXIS_RESULT_B2_Yi_0_tvalid(M_AXIS_RESULT_B2_Yi_0_tvalid),
        .M_AXIS_RESULT_B2_Yr_0_tdata(M_AXIS_RESULT_B2_Yr_0_tdata),
        .M_AXIS_RESULT_B2_Yr_0_tready(M_AXIS_RESULT_B2_Yr_0_tready),
        .M_AXIS_RESULT_B2_Yr_0_tvalid(M_AXIS_RESULT_B2_Yr_0_tvalid),
        .S_AXIS_B1_Ai_0_tdata(S_AXIS_B1_Ai_0_tdata),
        .S_AXIS_B1_Ai_0_tready(S_AXIS_B1_Ai_0_tready),
        .S_AXIS_B1_Ai_0_tvalid(S_AXIS_B1_Ai_0_tvalid),
        .S_AXIS_B1_Ar_0_tdata(S_AXIS_B1_Ar_0_tdata),
        .S_AXIS_B1_Ar_0_tready(S_AXIS_B1_Ar_0_tready),
        .S_AXIS_B1_Ar_0_tvalid(S_AXIS_B1_Ar_0_tvalid),
        .S_AXIS_B1_Bi_0_tdata(S_AXIS_B1_Bi_0_tdata),
        .S_AXIS_B1_Bi_0_tready(S_AXIS_B1_Bi_0_tready),
        .S_AXIS_B1_Bi_0_tvalid(S_AXIS_B1_Bi_0_tvalid),
        .S_AXIS_B1_Br_0_tdata(S_AXIS_B1_Br_0_tdata),
        .S_AXIS_B1_Br_0_tready(S_AXIS_B1_Br_0_tready),
        .S_AXIS_B1_Br_0_tvalid(S_AXIS_B1_Br_0_tvalid),
        .S_AXIS_B2_Ai_0_tdata(S_AXIS_B2_Ai_0_tdata),
        .S_AXIS_B2_Ai_0_tready(S_AXIS_B2_Ai_0_tready),
        .S_AXIS_B2_Ai_0_tvalid(S_AXIS_B2_Ai_0_tvalid),
        .S_AXIS_B2_Ar_0_tdata(S_AXIS_B2_Ar_0_tdata),
        .S_AXIS_B2_Ar_0_tready(S_AXIS_B2_Ar_0_tready),
        .S_AXIS_B2_Ar_0_tvalid(S_AXIS_B2_Ar_0_tvalid),
        .S_AXIS_B2_Bi_0_tdata(S_AXIS_B2_Bi_0_tdata),
        .S_AXIS_B2_Bi_0_tready(S_AXIS_B2_Bi_0_tready),
        .S_AXIS_B2_Bi_0_tvalid(S_AXIS_B2_Bi_0_tvalid),
        .S_AXIS_B2_Br_0_tdata(S_AXIS_B2_Br_0_tdata),
        .S_AXIS_B2_Br_0_tready(S_AXIS_B2_Br_0_tready),
        .S_AXIS_B2_Br_0_tvalid(S_AXIS_B2_Br_0_tvalid),
        .S_AXIS_F1_B1_Wi_tdata(S_AXIS_F1_B1_Wi_tdata),
        .S_AXIS_F1_B1_Wi_tready(S_AXIS_F1_B1_Wi_tready),
        .S_AXIS_F1_B1_Wi_tvalid(S_AXIS_F1_B1_Wi_tvalid),
        .S_AXIS_F1_B1_Wr_tdata(S_AXIS_F1_B1_Wr_tdata),
        .S_AXIS_F1_B1_Wr_tready(S_AXIS_F1_B1_Wr_tready),
        .S_AXIS_F1_B1_Wr_tvalid(S_AXIS_F1_B1_Wr_tvalid),
        .S_AXIS_F1_B2_Wi_tdata(S_AXIS_F1_B2_Wi_tdata),
        .S_AXIS_F1_B2_Wi_tready(S_AXIS_F1_B2_Wi_tready),
        .S_AXIS_F1_B2_Wi_tvalid(S_AXIS_F1_B2_Wi_tvalid),
        .S_AXIS_F1_B2_Wr_tdata(S_AXIS_F1_B2_Wr_tdata),
        .S_AXIS_F1_B2_Wr_tready(S_AXIS_F1_B2_Wr_tready),
        .S_AXIS_F1_B2_Wr_tvalid(S_AXIS_F1_B2_Wr_tvalid),
        .S_AXIS_F2_B1_Wi_tdata(S_AXIS_F2_B1_Wi_tdata),
        .S_AXIS_F2_B1_Wi_tready(S_AXIS_F2_B1_Wi_tready),
        .S_AXIS_F2_B1_Wi_tvalid(S_AXIS_F2_B1_Wi_tvalid),
        .S_AXIS_F2_B1_Wr_tdata(S_AXIS_F2_B1_Wr_tdata),
        .S_AXIS_F2_B1_Wr_tready(S_AXIS_F2_B1_Wr_tready),
        .S_AXIS_F2_B1_Wr_tvalid(S_AXIS_F2_B1_Wr_tvalid),
        .S_AXIS_F2_B2_Wi_tdata(S_AXIS_F2_B2_Wi_tdata),
        .S_AXIS_F2_B2_Wi_tready(S_AXIS_F2_B2_Wi_tready),
        .S_AXIS_F2_B2_Wi_tvalid(S_AXIS_F2_B2_Wi_tvalid),
        .S_AXIS_F2_B2_Wr_tdata(S_AXIS_F2_B2_Wr_tdata),
        .S_AXIS_F2_B2_Wr_tready(S_AXIS_F2_B2_Wr_tready),
        .S_AXIS_F2_B2_Wr_tvalid(S_AXIS_F2_B2_Wr_tvalid),
        .aclk(aclk),
        .aresetn(aresetn));
endmodule
