
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/20/2025 03:55:09 PM
// Design Name: 
// Module Name: Butterfly_4
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
`timescale 1 ns / 1 ps

module Butterfly_4 (
	output [63:0]M_AXIS_RESULT_B1_Xi_tdata,
	output M_AXIS_RESULT_B1_Xi_tvalid,
	output [63:0]M_AXIS_RESULT_B1_Xr_tdata,  
	output M_AXIS_RESULT_B1_Xr_tvalid,
	output [63:0]M_AXIS_RESULT_B1_Yi_tdata,  
	output M_AXIS_RESULT_B1_Yi_tvalid,
	output [63:0]M_AXIS_RESULT_B1_Yr_tdata,
	output M_AXIS_RESULT_B1_Yr_tvalid,
	output S_AXIS_B1_Ai_tready, 
	output S_AXIS_B1_Ar_tready,
	output S_AXIS_B1_Bi_tready,
	output S_AXIS_B1_Br_tready,
	output S_AXIS_B1_Wi_tready,
	output S_AXIS_B1_Wr_tready,
	
    output [63:0]M_AXIS_RESULT_B2_Xi_tdata,
	output M_AXIS_RESULT_B2_Xi_tvalid,
	output [63:0]M_AXIS_RESULT_B2_Xr_tdata,  
	output M_AXIS_RESULT_B2_Xr_tvalid,
	output [63:0]M_AXIS_RESULT_B2_Yi_tdata,  
	output M_AXIS_RESULT_B2_Yi_tvalid,
	output [63:0]M_AXIS_RESULT_B2_Yr_tdata,
	output M_AXIS_RESULT_B2_Yr_tvalid,
	output S_AXIS_B2_Ai_tready, 
	output S_AXIS_B2_Ar_tready,
	output S_AXIS_B2_Bi_tready,
	output S_AXIS_B2_Br_tready,
	output S_AXIS_B2_Wi_tready,
	output S_AXIS_B2_Wr_tready,
		
	input M_AXIS_RESULT_B1_Xi_tready,
	input M_AXIS_RESULT_B1_Xr_tready,
	input M_AXIS_RESULT_B1_Yi_tready,
	input M_AXIS_RESULT_B1_Yr_tready,
	input [63:0]S_AXIS_B1_Ai_tdata,
	input S_AXIS_B1_Ai_tvalid,
	input [63:0]S_AXIS_B1_Ar_tdata,
	input S_AXIS_B1_Ar_tvalid,
	input [63:0]S_AXIS_B1_Bi_tdata,
	input S_AXIS_B1_Bi_tvalid,
	input [63:0]S_AXIS_B1_Br_tdata,
	input S_AXIS_B1_Br_tvalid,
	input [63:0]S_AXIS_B1_Wi_tdata,
	input S_AXIS_B1_Wi_tvalid,
	input [63:0]S_AXIS_B1_Wr_tdata,
	input S_AXIS_B1_Wr_tvalid,
	
	input M_AXIS_RESULT_B2_Xi_tready,
	input M_AXIS_RESULT_B2_Xr_tready,
	input M_AXIS_RESULT_B2_Yi_tready,
	input M_AXIS_RESULT_B2_Yr_tready,
	input [63:0]S_AXIS_B2_Ai_tdata,
	input S_AXIS_B2_Ai_tvalid,
	input [63:0]S_AXIS_B2_Ar_tdata,
	input S_AXIS_B2_Ar_tvalid,
	input [63:0]S_AXIS_B2_Bi_tdata,
	input S_AXIS_B2_Bi_tvalid,
	input [63:0]S_AXIS_B2_Br_tdata,
	input S_AXIS_B2_Br_tvalid,
	input [63:0]S_AXIS_B2_Wi_tdata,
	input S_AXIS_B2_Wi_tvalid,
	input [63:0]S_AXIS_B2_Wr_tdata,
	input S_AXIS_B2_Wr_tvalid,
	input aclk,
	input aresetn
  );
  
Butterfly_2 B1
		(.M_AXIS_RESULT_Xi_tdata(M_AXIS_RESULT_B1_Xi_tdata),
        .M_AXIS_RESULT_Xi_tready(M_AXIS_RESULT_B1_Xi_tready),
        .M_AXIS_RESULT_Xi_tvalid(M_AXIS_RESULT_B1_Xi_tvalid),
        .M_AXIS_RESULT_Xr_tdata(M_AXIS_RESULT_B1_Xr_tdata),
        .M_AXIS_RESULT_Xr_tready(M_AXIS_RESULT_B1_Xr_tready),
        .M_AXIS_RESULT_Xr_tvalid(M_AXIS_RESULT_B1_Xr_tvalid),
        .M_AXIS_RESULT_Yi_tdata(M_AXIS_RESULT_B1_Yi_tdata),
        .M_AXIS_RESULT_Yi_tready(M_AXIS_RESULT_B1_Yi_tready),
        .M_AXIS_RESULT_Yi_tvalid(M_AXIS_RESULT_B1_Yi_tvalid),
        .M_AXIS_RESULT_Yr_tdata(M_AXIS_RESULT_B1_Yr_tdata),
        .M_AXIS_RESULT_Yr_tready(M_AXIS_RESULT_B1_Yr_tready),
        .M_AXIS_RESULT_Yr_tvalid(M_AXIS_RESULT_B1_Yr_tvalid),
        .S_AXIS_Ai_tdata(S_AXIS_B1_Ai_tdata),
        .S_AXIS_Ai_tready(S_AXIS_B1_Ai_tready),
        .S_AXIS_Ai_tvalid(S_AXIS_B1_Ai_tvalid),
        .S_AXIS_Ar_tdata(S_AXIS_B1_Ar_tdata),
        .S_AXIS_Ar_tready(S_AXIS_B1_Ar_tready),
        .S_AXIS_Ar_tvalid(S_AXIS_B1_Ar_tvalid),
        .S_AXIS_Bi_tdata(S_AXIS_B1_Bi_tdata),
        .S_AXIS_Bi_tready(S_AXIS_B1_Bi_tready),
        .S_AXIS_Bi_tvalid(S_AXIS_B1_Bi_tvalid),
        .S_AXIS_Br_tdata(S_AXIS_B1_Br_tdata),
        .S_AXIS_Br_tready(S_AXIS_B1_Br_tready),
        .S_AXIS_Br_tvalid(S_AXIS_B1_Br_tvalid),
        .S_AXIS_Wi_tdata(S_AXIS_B1_Wi_tdata),
        .S_AXIS_Wi_tready(S_AXIS_B1_Wi_tready),
        .S_AXIS_Wi_tvalid(S_AXIS_B1_Wi_tvalid),
        .S_AXIS_Wr_tdata(S_AXIS_B1_Wr_tdata),
        .S_AXIS_Wr_tready(S_AXIS_B1_Wr_tready),
        .S_AXIS_Wr_tvalid(S_AXIS_B1_Wr_tvalid),
        .aclk(aclk),
        .aresetn(aresetn));
        
Butterfly_2 B2
		(.M_AXIS_RESULT_Xi_tdata(M_AXIS_RESULT_B2_Xi_tdata),
        .M_AXIS_RESULT_Xi_tready(M_AXIS_RESULT_B2_Xi_tready),
        .M_AXIS_RESULT_Xi_tvalid(M_AXIS_RESULT_B2_Xi_tvalid),
        .M_AXIS_RESULT_Xr_tdata(M_AXIS_RESULT_B2_Xr_tdata),
        .M_AXIS_RESULT_Xr_tready(M_AXIS_RESULT_B2_Xr_tready),
        .M_AXIS_RESULT_Xr_tvalid(M_AXIS_RESULT_B2_Xr_tvalid),
        .M_AXIS_RESULT_Yi_tdata(M_AXIS_RESULT_B2_Yi_tdata),
        .M_AXIS_RESULT_Yi_tready(M_AXIS_RESULT_B2_Yi_tready),
        .M_AXIS_RESULT_Yi_tvalid(M_AXIS_RESULT_B2_Yi_tvalid),
        .M_AXIS_RESULT_Yr_tdata(M_AXIS_RESULT_B2_Yr_tdata),
        .M_AXIS_RESULT_Yr_tready(M_AXIS_RESULT_B2_Yr_tready),
        .M_AXIS_RESULT_Yr_tvalid(M_AXIS_RESULT_B2_Yr_tvalid),
        .S_AXIS_Ai_tdata(S_AXIS_B2_Ai_tdata),
        .S_AXIS_Ai_tready(S_AXIS_B2_Ai_tready),
        .S_AXIS_Ai_tvalid(S_AXIS_B2_Ai_tvalid),
        .S_AXIS_Ar_tdata(S_AXIS_B2_Ar_tdata),
        .S_AXIS_Ar_tready(S_AXIS_B2_Ar_tready),
        .S_AXIS_Ar_tvalid(S_AXIS_B2_Ar_tvalid),
        .S_AXIS_Bi_tdata(S_AXIS_B2_Bi_tdata),
        .S_AXIS_Bi_tready(S_AXIS_B2_Bi_tready),
        .S_AXIS_Bi_tvalid(S_AXIS_B2_Bi_tvalid),
        .S_AXIS_Br_tdata(S_AXIS_B2_Br_tdata),
        .S_AXIS_Br_tready(S_AXIS_B2_Br_tready),
        .S_AXIS_Br_tvalid(S_AXIS_B2_Br_tvalid),
        .S_AXIS_Wi_tdata(S_AXIS_B2_Wi_tdata),
        .S_AXIS_Wi_tready(S_AXIS_B2_Wi_tready),
        .S_AXIS_Wi_tvalid(S_AXIS_B2_Wi_tvalid),
        .S_AXIS_Wr_tdata(S_AXIS_B2_Wr_tdata),
        .S_AXIS_Wr_tready(S_AXIS_B2_Wr_tready),
        .S_AXIS_Wr_tvalid(S_AXIS_B2_Wr_tvalid),
        .aclk(aclk),
        .aresetn(aresetn));
       
endmodule
